//
//  TellYou.h
//  TestFrameworkForMe
//
//  Created by trtc-chx on 2021/1/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TellYou : NSObject
- (void)talkToYou;
@end

NS_ASSUME_NONNULL_END
